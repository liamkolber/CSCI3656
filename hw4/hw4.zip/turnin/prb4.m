close all
format long




f = @(x) cos(3*pi*x);
fprime = @(x) -3*pi*sin(3*pi*x);